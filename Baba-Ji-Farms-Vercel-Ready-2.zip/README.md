# Baba Ji Farms — Vercel Ready

Complete Vite + React + TypeScript website.

Run locally:
`npm install`
`npm run dev`

Production:
`npm run build`

Vercel:
- Framework: Vite
- Build command: npm run build
- Output directory: dist
- No environment variables required
