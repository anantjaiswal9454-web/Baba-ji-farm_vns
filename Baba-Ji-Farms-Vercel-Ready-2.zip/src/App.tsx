import { useState } from "react";

const products = [
  ["Oyster Mushrooms", "₹149", "250g", "Tender, meaty and perfect for stir-fries, curries and grills.", "🍄"],
  ["Button Mushrooms", "₹129", "250g", "Classic white mushrooms with a clean, delicate flavour.", "🤍"],
  ["Milky Mushrooms", "₹159", "250g", "Firm-textured, naturally cultivated and wonderfully fresh.", "🌱"],
  ["Gourmet Mix", "₹249", "300g", "A chef-style selection for richer textures and flavours.", "✨"]
];

export default function App() {
  const [cart, setCart] = useState(0);
  const [menu, setMenu] = useState(false);
  const [toast, setToast] = useState("");

  const go = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenu(false);
  };

  const add = (name: string) => {
    setCart(v => v + 1);
    setToast(`${name} added to your basket`);
    window.setTimeout(() => setToast(""), 1800);
  };

  return <div className="site">
    <header className="nav">
      <button className="brand" onClick={() => go("home")}>
        <span className="brand-mark">BJ</span>
        <span><strong>Baba Ji Farms</strong><small>Fresh from our farm</small></span>
      </button>
      <button className="menu-button" onClick={() => setMenu(!menu)}>{menu ? "✕" : "☰"}</button>
      <nav className={menu ? "nav-links open" : "nav-links"}>
        <button onClick={() => go("home")}>Home</button>
        <button onClick={() => go("story")}>Our Story</button>
        <button onClick={() => go("products")}>Mushrooms</button>
        <button onClick={() => go("why")}>Why Us</button>
        <button onClick={() => go("contact")}>Contact</button>
        <button className="cart" onClick={() => go("products")}>Basket · {cart}</button>
      </nav>
    </header>

    <main>
      <section id="home" className="hero">
        <div className="hero-copy">
          <p className="eyebrow">FARM GROWN · NATURALLY NOURISHING</p>
          <h1>Good food begins<br/><em>at the farm.</em></h1>
          <p className="intro">Fresh mushrooms cultivated with patience, care and clean farming practices — harvested at their best and brought straight to your table.</p>
          <div className="actions">
            <button className="primary" onClick={() => go("products")}>Explore Fresh Harvest →</button>
            <button className="under" onClick={() => go("story")}>Discover our story</button>
          </div>
          <div className="stats">
            <div><b>100%</b><span>Farm fresh</span></div>
            <div><b>24–48h</b><span>Harvest to home</span></div>
            <div><b>4+</b><span>Fresh varieties</span></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="disc"></div>
          <div className="mush m1"><i></i><b></b></div>
          <div className="mush m2"><i></i><b></b></div>
          <div className="mush m3"><i></i><b></b></div>
          <div className="leaf l1">❧</div><div className="leaf l2">❧</div>
          <div className="stamp">HARVEST<br/><strong>FRESH</strong></div>
        </div>
      </section>

      <div className="marquee"><span>FRESH · LOCAL · NATURAL</span><span>FRESH · LOCAL · NATURAL</span><span>FRESH · LOCAL · NATURAL</span></div>

      <section id="story" className="section story">
        <div className="tag">01 / OUR STORY</div>
        <div className="two">
          <h2>From our growing rooms<br/><em>to your kitchen.</em></h2>
          <div><p className="lead">We believe the best produce doesn't need to travel far.</p><p>Baba Ji Farms is built around a simple idea: grow wholesome mushrooms carefully, harvest them fresh, and make it easier for families to enjoy nutritious food every day.</p><p>Every batch is grown with attention to cleanliness, consistency and freshness — because you should know where your food comes from.</p></div>
        </div>
      </section>

      <section id="products" className="section products">
        <div className="heading"><div><div className="tag">02 / FRESH HARVEST</div><h2>Choose your<br/><em>favourite fungi.</em></h2></div><p>Picked for freshness.<br/>Packed with care.</p></div>
        <div className="grid">
          {products.map(([name, price, weight, desc, icon]) => <article className="card" key={name}>
            <div className="visual"><span>{icon}</span><small>FRESH</small></div>
            <div className="info"><div className="top"><div><h3>{name}</h3><label>{weight}</label></div><strong>{price}</strong></div><p>{desc}</p><button onClick={() => add(name)}>Add to basket <b>+</b></button></div>
          </article>)}
        </div>
      </section>

      <section id="why" className="section why">
        <div><div className="tag">03 / THE BABA JI WAY</div><h2>Freshness you can<br/><em>feel good about.</em></h2></div>
        <div className="features">
          <div><span>01</span><div><h3>Grown with care</h3><p>Thoughtful cultivation from growing room to harvest.</p></div></div>
          <div><span>02</span><div><h3>Harvested fresh</h3><p>We prioritise short farm-to-kitchen journeys.</p></div></div>
          <div><span>03</span><div><h3>Simple & wholesome</h3><p>Fresh produce without unnecessary complexity.</p></div></div>
        </div>
      </section>

      <section className="section quote"><div className="qmark">“</div><blockquote>Food tastes different when you know it was grown with patience.</blockquote><p>— Baba Ji Farms</p></section>

      <section id="contact" className="section contact">
        <div><div className="tag">04 / SAY HELLO</div><h2>Bring the harvest<br/><em>home.</em></h2></div>
        <div className="contact-card"><p>Want fresh mushrooms for your home, restaurant or next meal?</p><a href="mailto:hello@babajifarms.in">hello@babajifarms.in</a><button className="primary" onClick={() => setToast("Thanks! We'll be in touch soon.")}>Get in touch →</button></div>
      </section>
    </main>

    <footer><div className="brand"><span className="brand-mark">BJ</span><span><strong>Baba Ji Farms</strong><small>Fresh from our farm</small></span></div><p>© 2026 Baba Ji Farms. Grown with care.</p><button onClick={() => go("home")}>Back to top ↑</button></footer>
    {toast && <div className="toast">{toast}</div>}
  </div>;
}